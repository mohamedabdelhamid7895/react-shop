import React, { useContext } from 'react';
import { CounterContext } from './counterContext';

const  Counter=()=> {
    const { count,setCount } = useContext(CounterContext);

        return (
            <div>
                <h1>Counter:{count}</h1>
                <button onClick={() => setCount(count + 1)}>Increment</button>
                <button onClick={() => setCount(count - 1)}>Decrement</button>
            </div>
        );
    }


export default Counter;
