import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Card, Button } from 'react-bootstrap';

const SelectedProduct = ({ products }) => {
  const { id } = useParams();
  const [product, setProduct] = useState({});

  useEffect(() => {
    setProduct(products.find((p) => p.id === parseInt(id)));
  }, [products, id]);

  return (
    <div className="text-center">
      <Card>
        <Card.Img variant="top" src={product.img_src} />
        <Card.Body>
          <Card.Title>{product.title}</Card.Title>
          <Card.Text>{product.description}</Card.Text>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Price: {product.price}</small>
        </Card.Footer>
        <Button variant="primary">Buy Now</Button>
      </Card>
    </div>
  );
};

export default SelectedProduct;
